#speed test

if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import xbmc
import xbmcgui
import xbmcaddon
try :
 import xml . etree . cElementTree as ET
 from xml . dom import minidom as DOM
except ImportError :
 try :
  import xml . etree . ElementTree as ET
 except ImportError :
  from xml . dom import minidom as DOM
  ET = None
  if 73 - 73: II111iiii
  if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
I1IiI = 'plugin.program.onenationportal'
o0OOO = xbmcaddon . Addon ( I1IiI )
iIiiiI = o0OOO . getAddonInfo ( 'id' )
Iii1ii1II11i = o0OOO . getAddonInfo ( 'name' )
iI111iI = o0OOO . getAddonInfo ( 'icon' )
IiII = o0OOO . getAddonInfo ( 'version' )
iI1Ii11111iIi = xbmc . translatePath ( "special://profile/addon_data/%s/" % I1IiI )
i1i1II = o0OOO . getAddonInfo ( "path" )
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
if 56 - 56: ooO00oOoo - O0OOo
II1Iiii1111i = 10
i1IIi11111i = 92
if 74 - 74: o00 * Oo0oO0ooo
oo00o0Oo0oo = False
if 20 - 20: O0OOo * II111iiii
if 65 - 65: o0oOOo0O0Ooo * iIii1I11I1II1 * O0OOo
if 18 - 18: iIii1I11I1II1 / I1i1iI1i + o0OO0 / Oo0Ooo - II111iiii - I1i1iI1i
if 1 - 1: I1i1iI1i - Oo0ooO0oo0oO % O0 + I1IiiI - o00 / I1i1iI1i
if 31 - 31: OoO0O00 + II111iiii
import os
import re
import sys
import math
import signal
import socket
import timeit
import threading
if 13 - 13: Oo0ooO0oo0oO * o0OO0 * I1IiiI
__version__ = '0.3.2'
if 55 - 55: II111iiii
if 43 - 43: OoOoOO00 - i1IIi + ooO00oOoo + o00ooo0
iII111ii = 'speedtest-cli/%s' % __version__
i1iIIi1 = None
ii11iIi1I = None
if 6 - 6: OoOoOO00 * o00
if 67 - 67: O0OOo - o0OO0 * o0oOOo0O0Ooo % o0oOOo0O0Ooo % I1i1iI1i * OoOoOO00
i1IIiiiii = socket . socket
if 55 - 55: i1IIi
try :
 import xml . etree . cElementTree as ET
 from xml . dom import minidom as DOM
except ImportError :
 try :
  import xml . etree . ElementTree as ET
 except ImportError :
  from xml . dom import minidom as DOM
  ET = None
  if 70 - 70: OoO0O00 . OoO0O00 - OoO0O00 / I1ii11iIi11i * Oo0ooO0oo0oO
  if 86 - 86: i11iIiiIii + o00ooo0 + O0OOo * I1i1iI1i + o0oOOo0O0Ooo
try :
 from urllib2 import urlopen , Request , HTTPError , URLError
except ImportError :
 from urllib . request import urlopen , Request , HTTPError , URLError
 if 61 - 61: OoO0O00 / i11iIiiIii
try :
 from httplib import HTTPConnection , HTTPSConnection
except ImportError :
 from http . client import HTTPConnection , HTTPSConnection
 if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - I1ii11iIi11i + i11iIiiIii
try :
 from Queue import Queue
except ImportError :
 from queue import Queue
 if 65 - 65: OoOoOO00
try :
 from urlparse import urlparse
except ImportError :
 from urllib . parse import urlparse
 if 6 - 6: I1IiiI / Oo0Ooo % o00ooo0
try :
 from urlparse import parse_qs
except ImportError :
 try :
  from urllib . parse import parse_qs
 except ImportError :
  from cgi import parse_qs
  if 84 - 84: i11iIiiIii . o0oOOo0O0Ooo
try :
 from hashlib import md5
except ImportError :
 from md5 import md5
 if 100 - 100: o00ooo0 - o00ooo0 - ooO00oOoo
try :
 from argparse import ArgumentParser as ArgParser
except ImportError :
 from optparse import OptionParser as ArgParser
 if 20 - 20: OoooooooOO
try :
 import builtins
except ImportError :
 def Ii11iI1i ( * args , ** kwargs ) :
  Ooo = kwargs . pop ( "file" , sys . stdout )
  if 68 - 68: I1i1iI1i + Oo0ooO0oo0oO . iIii1I11I1II1 - Oo0oO0ooo % iIii1I11I1II1 - O0OOo
  if 79 - 79: Oo0Ooo + I1IiiI - o00
  if 83 - 83: O0OOo
  if 64 - 64: OoO0O00 % O0OOo % o00 / OoOoOO00 - OoO0O00
  if Ooo is None :
   return
   if 74 - 74: o00 * O0
  def oOOo0oo ( data ) :
   if not isinstance ( data , basestring ) :
    data = str ( data )
   Ooo . write ( data )
   if 80 - 80: I1i1iI1i * i11iIiiIii / ooO00oOoo
  I11II1i = False
  IIIII = kwargs . pop ( "sep" , None )
  if IIIII is not None :
   if isinstance ( IIIII , unicode ) :
    I11II1i = True
   elif not isinstance ( IIIII , str ) :
    raise TypeError ( "sep must be None or a string" )
  ooooooO0oo = kwargs . pop ( "end" , None )
  if ooooooO0oo is not None :
   if isinstance ( ooooooO0oo , unicode ) :
    I11II1i = True
   elif not isinstance ( ooooooO0oo , str ) :
    raise TypeError ( "end must be None or a string" )
  if kwargs :
   raise TypeError ( "invalid keyword arguments to print()" )
  if not I11II1i :
   for IIiiiiiiIi1I1 in args :
    if isinstance ( IIiiiiiiIi1I1 , unicode ) :
     I11II1i = True
     break
  if I11II1i :
   I1IIIii = unicode ( "\n" )
   oOoOooOo0o0 = unicode ( " " )
  else :
   I1IIIii = "\n"
   oOoOooOo0o0 = " "
  if IIIII is None :
   IIIII = oOoOooOo0o0
  if ooooooO0oo is None :
   ooooooO0oo = I1IIIii
  for OOOO , IIiiiiiiIi1I1 in enumerate ( args ) :
   if OOOO :
    oOOo0oo ( IIIII )
   oOOo0oo ( IIiiiiiiIi1I1 )
  oOOo0oo ( ooooooO0oo )
else :
 Ii11iI1i = getattr ( builtins , 'print' )
 del builtins
 if 87 - 87: o0OO0 / I1i1iI1i - i1IIi * Oo0ooO0oo0oO / OoooooooOO . O0
 if 1 - 1: II111iiii - I1i1iI1i / I1i1iI1i
class I1II1III11iii ( Exception ) :
 if 75 - 75: iIii1I11I1II1 / Oo0ooO0oo0oO % o0oOOo0O0Ooo * OoOoOO00
 if 9 - 9: OoO0O00
 if 33 - 33: O0OOo . o00
 if 58 - 58: Oo0ooO0oo0oO * i11iIiiIii / OoOoOO00 % ooO00oOoo - I1ii11iIi11i / o0OO0
 if 50 - 50: I1IiiI
 if 34 - 34: I1IiiI * II111iiii % o00 * OoOoOO00 - I1IiiI
def II1III ( * args , ** kwargs ) :
 if 19 - 19: o0OO0 % i1IIi % o0oOOo0O0Ooo
 if 93 - 93: iIii1I11I1II1 % o0OO0 * i1IIi
 global i1iIIi1
 Ii11Ii1I = i1IIiiiii ( * args , ** kwargs )
 Ii11Ii1I . bind ( ( i1iIIi1 , 0 ) )
 return Ii11Ii1I
 if 72 - 72: o00 / i1IIi * Oo0Ooo - ooO00oOoo
 if 51 - 51: II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % I1ii11iIi11i / O0OOo
def iIIIIii1 ( origin , destination ) :
 if 58 - 58: i11iIiiIii % I1i1iI1i
 if 71 - 71: Oo0ooO0oo0oO + O0OOo % i11iIiiIii + I1ii11iIi11i - Oo0oO0ooo
 oO0OOoO0 , I111Ii111 = origin
 i111IiI1I , O0iII = destination
 o0 = 6371
 if 62 - 62: iIii1I11I1II1 * OoOoOO00
 i1 = math . radians ( i111IiI1I - oO0OOoO0 )
 OOO = math . radians ( O0iII - I111Ii111 )
 Oo0oOOo = ( math . sin ( i1 / 2 ) * math . sin ( i1 / 2 ) +
 math . cos ( math . radians ( oO0OOoO0 ) ) *
 math . cos ( math . radians ( i111IiI1I ) ) * math . sin ( OOO / 2 ) *
 math . sin ( OOO / 2 ) )
 Oo0OoO00oOO0o = 2 * math . atan2 ( math . sqrt ( Oo0oOOo ) , math . sqrt ( 1 - Oo0oOOo ) )
 OOO00O = o0 * Oo0OoO00oOO0o
 if 84 - 84: o0OO0 * OoO0O00 / I1i1iI1i - O0
 return OOO00O
 if 30 - 30: iIii1I11I1II1 / O0OOo - ooO00oOoo - II111iiii % o00
 if 49 - 49: I1IiiI % O0OOo . O0OOo . I1i1iI1i * O0OOo
def O0oOO0 ( url , data = None , headers = { } ) :
 if 68 - 68: ooO00oOoo % i1IIi . Oo0oO0ooo . I1ii11iIi11i
 if 92 - 92: o00 . ooO00oOoo
 if 31 - 31: ooO00oOoo . OoOoOO00 / O0
 if 89 - 89: OoOoOO00
 if 68 - 68: OoO0O00 * OoooooooOO % O0 + OoO0O00 + O0OOo
 if 4 - 4: O0OOo + O0 * Oo0ooO0oo0oO
 headers [ 'User-Agent' ] = iII111ii
 return Request ( url , data = data , headers = headers )
 if 55 - 55: Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * o0OO0 - i11iIiiIii - o00ooo0
 if 25 - 25: I1ii11iIi11i
def Ii1i ( request ) :
 if 15 - 15: Oo0oO0ooo . iIii1I11I1II1 . OoooooooOO / i11iIiiIii - o00ooo0 . i1IIi
 if 33 - 33: I1i1iI1i . o0oOOo0O0Ooo
 if 75 - 75: o0oOOo0O0Ooo % o0oOOo0O0Ooo . ooO00oOoo
 if 5 - 5: o0oOOo0O0Ooo * O0OOo + OoOoOO00 . Oo0ooO0oo0oO + OoOoOO00
 if 91 - 91: O0
 try :
  oOOo0 = urlopen ( request )
  return oOOo0
 except ( HTTPError , URLError , socket . error ) :
  return False
  if 54 - 54: O0 - Oo0oO0ooo % Oo0ooO0oo0oO
  if 77 - 77: OoOoOO00 / I1IiiI / OoO0O00 + OoO0O00 . Oo0ooO0oo0oO
class ii1ii11IIIiiI ( threading . Thread ) :
 if 67 - 67: I1i1iI1i * o0OO0 * I1ii11iIi11i + Oo0ooO0oo0oO / i1IIi
 if 11 - 11: o00ooo0 + o00 - O0OOo * o0OO0 % i11iIiiIii - ooO00oOoo
 def __init__ ( self , url , start ) :
  self . url = url
  self . result = None
  self . starttime = start
  threading . Thread . __init__ ( self )
  if 83 - 83: I1i1iI1i / I1IiiI
 def run ( self ) :
  self . result = [ 0 ]
  try :
   if ( timeit . default_timer ( ) - self . starttime ) <= 10 :
    iIIiIi1iIII1 = O0oOO0 ( self . url )
    OooOOOOo = urlopen ( iIIiIi1iIII1 )
    while 1 and not ii11iIi1I . isSet ( ) :
     self . result . append ( len ( OooOOOOo . read ( 10240 ) ) )
     if self . result [ - 1 ] == 0 :
      break
    OooOOOOo . close ( )
  except IOError :
   pass
   if 76 - 76: OoO0O00
   if 29 - 29: Oo0ooO0oo0oO + Oo0Ooo . i11iIiiIii - i1IIi / iIii1I11I1II1
def i1iI11i1ii11 ( files , quiet = False ) :
 if 58 - 58: OoO0O00 % i11iIiiIii . o00 / o0OO0
 if 84 - 84: o00 . I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
 II111iiiI1Ii = timeit . default_timer ( )
 if 78 - 78: o00ooo0 % ooO00oOoo + I1ii11iIi11i
 def OOooOoooOoOo ( q , files ) :
  for file in files :
   o0OOOO00O0Oo = ii1ii11IIIiiI ( file , II111iiiI1Ii )
   o0OOOO00O0Oo . start ( )
   q . put ( o0OOOO00O0Oo , True )
   if not quiet and not ii11iIi1I . isSet ( ) :
    sys . stdout . write ( '.' )
    sys . stdout . flush ( )
    if 48 - 48: O0
 I1IiiIIIi = [ ]
 if 41 - 41: o00ooo0 - O0 - O0
 def oO00OOoO00 ( q , total_files ) :
  while len ( I1IiiIIIi ) < total_files :
   o0OOOO00O0Oo = q . get ( True )
   while o0OOOO00O0Oo . isAlive ( ) :
    o0OOOO00O0Oo . join ( timeout = 0.1 )
   I1IiiIIIi . append ( sum ( o0OOOO00O0Oo . result ) )
   del o0OOOO00O0Oo
   if 40 - 40: I1IiiI * o00ooo0 + Oo0ooO0oo0oO % o00
 OOOOOoo0 = Queue ( 6 )
 ii1 = threading . Thread ( target = OOooOoooOoOo , args = ( OOOOOoo0 , files ) )
 I1iI1iIi111i = threading . Thread ( target = oO00OOoO00 , args = ( OOOOOoo0 , len ( files ) ) )
 II111iiiI1Ii = timeit . default_timer ( )
 ii1 . start ( )
 I1iI1iIi111i . start ( )
 while ii1 . isAlive ( ) :
  ii1 . join ( timeout = 0.1 )
 while I1iI1iIi111i . isAlive ( ) :
  I1iI1iIi111i . join ( timeout = 0.1 )
 return ( sum ( I1IiiIIIi ) / ( timeit . default_timer ( ) - II111iiiI1Ii ) )
 if 44 - 44: i1IIi % II111iiii + I1i1iI1i
 if 45 - 45: o00 / o00 + ooO00oOoo + O0OOo
class iI111i ( threading . Thread ) :
 if 26 - 26: I1ii11iIi11i * o00 . II111iiii * o00ooo0
 if 28 - 28: OoO0O00 . i1IIi * I1IiiI + O0 . i1IIi - O0OOo
 def __init__ ( self , url , start , size ) :
  self . url = url
  i1I1ii11i1Iii = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
  I1IiiiiI = i1I1ii11i1Iii * ( int ( round ( int ( size ) / 36.0 ) ) )
  self . data = ( 'content1=%s' % I1IiiiiI [ 0 : int ( size ) - 9 ] ) . encode ( )
  del I1IiiiiI
  self . result = None
  self . starttime = start
  threading . Thread . __init__ ( self )
  if 80 - 80: ooO00oOoo . i11iIiiIii - o0oOOo0O0Ooo
 def run ( self ) :
  try :
   if ( ( timeit . default_timer ( ) - self . starttime ) <= 10 and
 not ii11iIi1I . isSet ( ) ) :
    iIIiIi1iIII1 = O0oOO0 ( self . url , data = self . data )
    OooOOOOo = urlopen ( iIIiIi1iIII1 )
    OooOOOOo . read ( 11 )
    OooOOOOo . close ( )
    self . result = len ( self . data )
   else :
    self . result = 0
  except IOError :
   self . result = 0
   if 25 - 25: OoO0O00
   if 62 - 62: Oo0ooO0oo0oO + O0
def oO0OOOO0 ( url , sizes , quiet = False ) :
 if 26 - 26: o00ooo0
 if 35 - 35: o00ooo0 - I1IiiI % o0oOOo0O0Ooo . OoooooooOO % o00ooo0
 II111iiiI1Ii = timeit . default_timer ( )
 if 47 - 47: o00 - o00ooo0 . II111iiii + OoooooooOO . i11iIiiIii
 def OOooOoooOoOo ( q , sizes ) :
  for OOo0oO00ooO00 in sizes :
   o0OOOO00O0Oo = iI111i ( url , II111iiiI1Ii , OOo0oO00ooO00 )
   o0OOOO00O0Oo . start ( )
   q . put ( o0OOOO00O0Oo , True )
   if not quiet and not ii11iIi1I . isSet ( ) :
    sys . stdout . write ( '.' )
    sys . stdout . flush ( )
    if 90 - 90: OoOoOO00 * ooO00oOoo + o0oOOo0O0Ooo
 I1IiiIIIi = [ ]
 if 81 - 81: o0OO0 . o0oOOo0O0Ooo % O0 / I1IiiI - o0OO0
 def oO00OOoO00 ( q , total_sizes ) :
  while len ( I1IiiIIIi ) < total_sizes :
   o0OOOO00O0Oo = q . get ( True )
   while o0OOOO00O0Oo . isAlive ( ) :
    o0OOOO00O0Oo . join ( timeout = 0.1 )
   I1IiiIIIi . append ( o0OOOO00O0Oo . result )
   del o0OOOO00O0Oo
   if 43 - 43: i11iIiiIii + Oo0Ooo * II111iiii * ooO00oOoo * O0
 OOOOOoo0 = Queue ( 6 )
 ii1 = threading . Thread ( target = OOooOoooOoOo , args = ( OOOOOoo0 , sizes ) )
 I1iI1iIi111i = threading . Thread ( target = oO00OOoO00 , args = ( OOOOOoo0 , len ( sizes ) ) )
 II111iiiI1Ii = timeit . default_timer ( )
 ii1 . start ( )
 I1iI1iIi111i . start ( )
 while ii1 . isAlive ( ) :
  ii1 . join ( timeout = 0.1 )
 while I1iI1iIi111i . isAlive ( ) :
  I1iI1iIi111i . join ( timeout = 0.1 )
 return ( sum ( I1IiiIIIi ) / ( timeit . default_timer ( ) - II111iiiI1Ii ) )
 if 64 - 64: Oo0ooO0oo0oO % iIii1I11I1II1 * o0OO0
 if 79 - 79: O0
def oOO00O ( dom , tagName ) :
 OOOoo0OO = dom . getElementsByTagName ( tagName ) [ 0 ]
 if 57 - 57: OoO0O00 / O0OOo
 if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * Oo0ooO0oo0oO . I1IiiI * I1IiiI
 if 7 - 7: Oo0oO0ooo * ooO00oOoo % o00ooo0 - o0oOOo0O0Ooo
 if 13 - 13: o00ooo0 . i11iIiiIii
 if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
 if 100 - 100: o00ooo0 - O0 % o0OO0 * Oo0ooO0oo0oO + I1IiiI
 return dict ( list ( OOOoo0OO . attributes . items ( ) ) )
 if 88 - 88: OoooooooOO - OoO0O00 * O0 * OoooooooOO . OoooooooOO
 if 33 - 33: ooO00oOoo + o00 * o0OO0 / iIii1I11I1II1 - I1IiiI
def O0oO ( ) :
 if 73 - 73: I1ii11iIi11i * i11iIiiIii % o0OO0 . I1ii11iIi11i
 if 66 - 66: o0OO0 + o0OO0 + O0OOo / o00 + Oo0ooO0oo0oO
 if 30 - 30: O0
 if 44 - 44: o0OO0 / I1i1iI1i / I1i1iI1i
 iIIiIi1iIII1 = O0oOO0 ( 'https://www.speedtest.net/speedtest-config.php' )
 oOOo0 = Ii1i ( iIIiIi1iIII1 )
 if oOOo0 is False :
  Ii11iI1i ( 'Could not retrieve speedtest.net configuration' )
  sys . exit ( 1 )
 OOOiiiiI = [ ]
 while 1 :
  OOOiiiiI . append ( oOOo0 . read ( 10240 ) )
  if len ( OOOiiiiI [ - 1 ] ) == 0 :
   break
 if int ( oOOo0 . code ) != 200 :
  return None
 oOOo0 . close ( )
 try :
  try :
   oooOo0OOOoo0 = ET . fromstring ( '' . encode ( ) . join ( OOOiiiiI ) )
   OOoO = {
 'client' : oooOo0OOOoo0 . find ( 'client' ) . attrib ,
 'times' : oooOo0OOOoo0 . find ( 'times' ) . attrib ,
 'download' : oooOo0OOOoo0 . find ( 'download' ) . attrib ,
 'upload' : oooOo0OOOoo0 . find ( 'upload' ) . attrib }
  except Exception , OO0O000 :
   xbmc . log ( 'Exception for ET: ' + str ( OO0O000 ) , level = xbmc . LOGDEBUG )
   oooOo0OOOoo0 = DOM . parseString ( '' . join ( OOOiiiiI ) )
   OOoO = {
 'client' : oOO00O ( oooOo0OOOoo0 , 'client' ) ,
 'times' : oOO00O ( oooOo0OOOoo0 , 'times' ) ,
 'download' : oOO00O ( oooOo0OOOoo0 , 'download' ) ,
 'upload' : oOO00O ( oooOo0OOOoo0 , 'upload' ) }
 except SyntaxError :
  Ii11iI1i ( 'Failed to parse speedtest.net configuration' )
  sys . exit ( 1 )
 del oooOo0OOOoo0
 del OOOiiiiI
 return OOoO
 if 37 - 37: OoooooooOO - O0 - o0oOOo0O0Ooo
 if 77 - 77: Oo0ooO0oo0oO * iIii1I11I1II1
def oO00oOOoooO ( client , all = False ) :
 if 46 - 46: I1IiiI - OoooooooOO - I1i1iI1i * II111iiii
 if 34 - 34: I1i1iI1i - o00 / Oo0ooO0oo0oO + I1ii11iIi11i * o00ooo0
 if 73 - 73: OoOoOO00 . o00ooo0 * I1ii11iIi11i % I1ii11iIi11i % OoooooooOO
 if 63 - 63: iIii1I11I1II1 * i11iIiiIii % iIii1I11I1II1 * i11iIiiIii
 iI1111iiii = [
 'https://www.speedtest.net/speedtest-servers-static.php' ,
 'http://c.speedtest.net/speedtest-servers-static.php' ,
 ]
 Oo0OO = { }
 for O0OooOo0o in iI1111iiii :
  try :
   iIIiIi1iIII1 = O0oOO0 ( O0OooOo0o )
   oOOo0 = Ii1i ( iIIiIi1iIII1 )
   if oOOo0 is False :
    raise I1II1III11iii
   iiI11ii1I1 = [ ]
   while 1 :
    iiI11ii1I1 . append ( oOOo0 . read ( 10240 ) )
    if len ( iiI11ii1I1 [ - 1 ] ) == 0 :
     break
   if int ( oOOo0 . code ) != 200 :
    oOOo0 . close ( )
    raise I1II1III11iii
   oOOo0 . close ( )
   try :
    try :
     oooOo0OOOoo0 = ET . fromstring ( '' . encode ( ) . join ( iiI11ii1I1 ) )
     Ooo0OOoOoO0 = oooOo0OOOoo0 . getiterator ( 'server' )
    except Exception , OO0O000 :
     xbmc . log ( 'Exception for ET: ' + str ( OO0O000 ) , level = xbmc . LOGDEBUG )
     oooOo0OOOoo0 = DOM . parseString ( '' . join ( iiI11ii1I1 ) )
     Ooo0OOoOoO0 = oooOo0OOOoo0 . getElementsByTagName ( 'server' )
   except SyntaxError :
    raise I1II1III11iii
   for oOo0OOoO0 in Ooo0OOoOoO0 :
    try :
     II = oOo0OOoO0 . attrib
    except AttributeError :
     II = dict ( list ( oOo0OOoO0 . attributes . items ( ) ) )
    OOO00O = iIIIIii1 ( [ float ( client [ 'lat' ] ) ,
 float ( client [ 'lon' ] ) ] ,
 [ float ( II . get ( 'lat' ) ) ,
 float ( II . get ( 'lon' ) ) ] )
    II [ 'd' ] = OOO00O
    if OOO00O not in Oo0OO :
     Oo0OO [ OOO00O ] = [ II ]
    else :
     Oo0OO [ OOO00O ] . append ( II )
   del oooOo0OOOoo0
   del iiI11ii1I1
   del Ooo0OOoOoO0
  except I1II1III11iii :
   continue
   if 93 - 93: Oo0oO0ooo * OoooooooOO + O0OOo
   if 33 - 33: O0 * o0oOOo0O0Ooo - ooO00oOoo % ooO00oOoo
  if Oo0OO :
   break
   if 18 - 18: ooO00oOoo / Oo0Ooo * ooO00oOoo + ooO00oOoo * i11iIiiIii * I1ii11iIi11i
 if not Oo0OO :
  Ii11iI1i ( 'Failed to retrieve list of speedtest.net servers' )
  sys . exit ( 1 )
  if 11 - 11: O0OOo / OoOoOO00 - Oo0oO0ooo * OoooooooOO + OoooooooOO . OoOoOO00
 i1I1i111Ii = [ ]
 for OOO00O in sorted ( Oo0OO . keys ( ) ) :
  for ooo in Oo0OO [ OOO00O ] :
   i1I1i111Ii . append ( ooo )
   if len ( i1I1i111Ii ) == 5 and not all :
    break
  else :
   continue
  break
  if 27 - 27: O0OOo % I1IiiI
 del Oo0OO
 return i1I1i111Ii
 if 73 - 73: Oo0ooO0oo0oO
 if 70 - 70: iIii1I11I1II1
def i11ii1iI ( servers ) :
 if 22 - 22: OoooooooOO
 if 75 - 75: o0oOOo0O0Ooo + o0oOOo0O0Ooo + i1IIi - i1IIi
 if 76 - 76: OoO0O00 . O0 % O0 - o0oOOo0O0Ooo - iIii1I11I1II1 - I1IiiI
 if 53 - 53: i1IIi
 o0OOOoO0 = { }
 for oOo0OOoO0 in servers :
  o0OoOo00o0o = [ ]
  O0OooOo0o = '%s/latency.txt' % os . path . dirname ( oOo0OOoO0 [ 'url' ] )
  I1II1I11I1I = urlparse ( O0OooOo0o )
  for OOOO in range ( 0 , 3 ) :
   try :
    if I1II1I11I1I [ 0 ] == 'https' :
     OoOO0o = HTTPSConnection ( I1II1I11I1I [ 1 ] )
    else :
     OoOO0o = HTTPConnection ( I1II1I11I1I [ 1 ] )
    i1II1 = { 'User-Agent' : iII111ii }
    II111iiiI1Ii = timeit . default_timer ( )
    OoOO0o . request ( "GET" , I1II1I11I1I [ 2 ] , headers = i1II1 )
    i11i1 = OoOO0o . getresponse ( )
    IiiiiI1i1Iii = ( timeit . default_timer ( ) - II111iiiI1Ii )
   except ( HTTPError , URLError , socket . error ) :
    o0OoOo00o0o . append ( 3600 )
    continue
   oo00oO0o = i11i1 . read ( 9 )
   if int ( i11i1 . status ) == 200 and oo00oO0o == 'test=test' . encode ( ) :
    o0OoOo00o0o . append ( IiiiiI1i1Iii )
   else :
    o0OoOo00o0o . append ( 3600 )
   OoOO0o . close ( )
  iiii111II = round ( ( sum ( o0OoOo00o0o ) / 6 ) * 1000 , 3 )
  o0OOOoO0 [ iiii111II ] = oOo0OOoO0
 I11iIiI1I1i11 = sorted ( o0OOOoO0 . keys ( ) ) [ 0 ]
 OOoooO00o0oo0 = o0OOOoO0 [ I11iIiI1I1i11 ]
 OOoooO00o0oo0 [ 'latency' ] = I11iIiI1I1i11
 if 61 - 61: o00ooo0 / I1ii11iIi11i % Oo0oO0ooo + O0OOo / ooO00oOoo . O0OOo
 return OOoooO00o0oo0
 if 12 - 12: i1IIi + i1IIi - I1ii11iIi11i * Oo0Ooo % Oo0Ooo - II111iiii
 if 52 - 52: O0OOo . o00 + ooO00oOoo
def iiii1IIi ( signum , frame ) :
 if 33 - 33: OoOoOO00 * Oo0ooO0oo0oO - II111iiii
 if 83 - 83: OoOoOO00 - o00ooo0 / I1i1iI1i / ooO00oOoo + o0OO0 - O0
 if 4 - 4: Oo0ooO0oo0oO * OoO0O00 % i1IIi * i11iIiiIii % Oo0Ooo - o0OO0
 if 67 - 67: OoOoOO00 + I1ii11iIi11i . o0oOOo0O0Ooo . II111iiii
 global ii11iIi1I
 ii11iIi1I . set ( )
 raise SystemExit ( '\nCancelling...' )
 if 98 - 98: o00
 if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / II111iiii % Oo0Ooo
 if 38 - 38: O0OOo - Oo0ooO0oo0oO / o00
 if 66 - 66: O0 % I1ii11iIi11i + i11iIiiIii . OoOoOO00 / o00ooo0 + I1ii11iIi11i
 if 86 - 86: o0oOOo0O0Ooo
 if 5 - 5: Oo0oO0ooo * OoOoOO00
def i1Ii1i1I11Iii ( list = False , mini = None , server = None , share = False , simple = False , src = None , timeout = 10 , units = ( 'bit' , 8 ) , version = False ) :
 I1i1i1 = xbmcgui . DialogProgress ( )
 OoO0O00O0oo0O = [ ' ' , ' ' , ' ' ]
 I1i1i1 . create ('[COLOR ghostwhite][B] Speed Test Powered By Ookla[/B][/COLOR]' , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 I1i1i1 . update ( 0 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 if 36 - 36: Oo0ooO0oo0oO + O0 - o00ooo0 - O0 % I1i1iI1i . o0OO0
 if 74 - 74: i11iIiiIii . I1IiiI
 if 36 - 36: OoooooooOO . OoO0O00
 global ii11iIi1I , i1iIIi1
 ii11iIi1I = threading . Event ( )
 if 56 - 56: Oo0Ooo . I1ii11iIi11i . I1IiiI
 if 39 - 39: O0 + ooO00oOoo
 if 91 - 91: OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoOoOO00 + O0
 iIiii1iI1 = (
 'Command line interface for testing internet bandwidth using '
 'speedtest.net.\n'
 '------------------------------------------------------------'
 '--------------\n'
 'https://github.com/sivel/speedtest-cli' )
 if 33 - 33: Oo0oO0ooo % iIii1I11I1II1 * I1IiiI
 if 95 - 95: O0OOo / O0OOo
 if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
 if version :
  version ( )
  if 55 - 55: O0OOo - I1i1iI1i + II111iiii + o00 % o00ooo0
 socket . setdefaulttimeout ( timeout )
 if 41 - 41: i1IIi - I1i1iI1i - o00ooo0
 if 8 - 8: OoO0O00 + ooO00oOoo - o0oOOo0O0Ooo % Oo0Ooo % o0oOOo0O0Ooo * o0OO0
 if src :
  i1iIIi1 = src
  socket . socket = II1III
  if 9 - 9: Oo0Ooo - i11iIiiIii - Oo0ooO0oo0oO * o00ooo0 + O0OOo
 OoO0O00O0oo0O [ 0 ] = 'Retrieving speedtest.net configuration...'
 I1i1i1 . update ( 10 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 if not simple :
  Ii11iI1i ( 'Retrieving speedtest.net configuration...' )
 try :
  OOoO = O0oO ( )
 except URLError :
  I1i1i1 . close ( )
  Ii11iI1i ( 'Cannot retrieve speedtest configuration' )
  sys . exit ( 1 )
  if 44 - 44: II111iiii
 OoO0O00O0oo0O [ 1 ] = 'Retrieving speedtest.net server list...'
 I1i1i1 . update ( 15 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 if not simple :
  Ii11iI1i ( 'Retrieving speedtest.net server list...' )
 if list or server :
  Oo0OO = oO00oOOoooO ( OOoO [ 'client' ] , True )
  if list :
   OOOO0OOO = [ ]
   for server in Oo0OO :
    i1i1ii = ( '%(id)4s) %(sponsor)s (%(name)s, %(country)s) '
 '[%(d)0.2f km]' % server )
    OOOO0OOO . append ( i1i1ii )
    if 46 - 46: OoOoOO00 + OoO0O00
    if 70 - 70: o00 / iIii1I11I1II1
    if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / I1ii11iIi11i
   try :
    unicode ( )
    Ii11iI1i ( '\n' . join ( OOOO0OOO ) . encode ( 'utf-8' , 'ignore' ) )
   except NameError :
    Ii11iI1i ( '\n' . join ( OOOO0OOO ) )
   except IOError :
    pass
   sys . exit ( 0 )
 else :
  Oo0OO = oO00oOOoooO ( OOoO [ 'client' ] )
  if 96 - 96: OoooooooOO + o0OO0
 OoO0O00O0oo0O [ 2 ] = 'Testing from %(isp)s (%(ip)s)...' % OOoO [ 'client' ]
 I1i1i1 . update ( 25 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 if not simple :
  Ii11iI1i ( 'Testing from %(isp)s (%(ip)s)...' % OOoO [ 'client' ] )
  if 44 - 44: o0OO0
 if server :
  try :
   OOoooO00o0oo0 = i11ii1iI ( filter ( lambda I1i11i : I1i11i [ 'id' ] == server ,
 Oo0OO ) )
  except IndexError :
   I1i1i1 . close ( )
   Ii11iI1i ( 'Invalid server ID' )
   sys . exit ( 1 )
 elif mini :
  IiIi , OOOOO0O00 = os . path . splitext ( mini )
  if OOOOO0O00 :
   O0OooOo0o = os . path . dirname ( mini )
  else :
   O0OooOo0o = mini
  I1II1I11I1I = urlparse ( O0OooOo0o )
  try :
   iIIiIi1iIII1 = O0oOO0 ( mini )
   OooOOOOo = urlopen ( iIIiIi1iIII1 )
  except :
   Ii11iI1i ( 'Invalid Speedtest Mini URL' )
   sys . exit ( 1 )
  else :
   oo00oO0o = OooOOOOo . read ( )
   OooOOOOo . close ( )
  Iii = re . findall ( 'upload_extension: "([^"]+)"' , oo00oO0o . decode ( ) )
  if not Iii :
   for OOOOO0O00 in [ 'php' , 'asp' , 'aspx' , 'jsp' ] :
    try :
     iIIiIi1iIII1 = O0oOO0 ( '%s/speedtest/upload.%s' %
 ( mini , OOOOO0O00 ) )
     OooOOOOo = urlopen ( iIIiIi1iIII1 )
    except :
     pass
    else :
     I1IiiiiI = OooOOOOo . read ( ) . strip ( )
     if ( OooOOOOo . code == 200 and
 len ( I1IiiiiI . splitlines ( ) ) == 1 and
 re . match ( 'size=[0-9]' , I1IiiiiI ) ) :
      Iii = [ OOOOO0O00 ]
      break
  if not I1II1I11I1I or not Iii :
   Ii11iI1i ( 'Please provide the full URL of your Speedtest Mini server' )
   sys . exit ( 1 )
  Oo0OO = [ {
 'sponsor' : 'Speedtest Mini' ,
 'name' : I1II1I11I1I [ 1 ] ,
 'd' : 0 ,
 'url' : '%s/speedtest/upload.%s' % ( O0OooOo0o . rstrip ( '/' ) , Iii [ 0 ] ) ,
 'latency' : 0 ,
 'id' : 0
 } ]
  try :
   OOoooO00o0oo0 = i11ii1iI ( Oo0OO )
  except :
   OOoooO00o0oo0 = Oo0OO [ 0 ]
 else :
  if not simple :
   OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
   OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
   OoO0O00O0oo0O [ 2 ] = 'Selecting best server based on latency...'
   I1i1i1 . update ( 30 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
   Ii11iI1i ( 'Selecting best server based on latency...' )
  OOoooO00o0oo0 = i11ii1iI ( Oo0OO )
  if 31 - 31: o0oOOo0O0Ooo % OoO0O00
 if not simple :
  if 14 - 14: o0OO0 / o0OO0 % O0OOo
  if 56 - 56: I1IiiI . O0 + Oo0Ooo
  if 1 - 1: o00
  try :
   unicode ( )
   OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
   OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
   OoO0O00O0oo0O [ 2 ] = ( 'Hosted by %(sponsor)s (%(name)s) [%(d)0.2f km]: %(latency)s ms' % OOoooO00o0oo0 ) . encode ( 'utf-8' , 'ignore' )
   I1i1i1 . update ( 40 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
   Ii11iI1i ( ( 'Hosted by %(sponsor)s (%(name)s) [%(d)0.2f km]: '
 '%(latency)s ms' % OOoooO00o0oo0 ) . encode ( 'utf-8' , 'ignore' ) )
  except NameError :
   OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
   OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
   OoO0O00O0oo0O [ 2 ] = 'Hosted by %(sponsor)s (%(name)s) [%(d)0.2f km]: %(latency)s ms' % OOoooO00o0oo0
   I1i1i1 . update ( 40 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
   Ii11iI1i ( 'Hosted by %(sponsor)s (%(name)s) [%(d)0.2f km]: '
 '%(latency)s ms' % OOoooO00o0oo0 )
 else :
  OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
  OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
  OoO0O00O0oo0O [ 2 ] = 'Ping: %(latency)s ms' % OOoooO00o0oo0
  I1i1i1 . update ( 40 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
  Ii11iI1i ( 'Ping: %(latency)s ms' % OOoooO00o0oo0 )
  if 97 - 97: Oo0ooO0oo0oO + o00 + O0 + i11iIiiIii
 oOoO0 = [ 350 , 500 , 750 , 1000 , 1500 , 2000 , 2500 , 3000 , 3500 , 4000 ]
 iI1111iiii = [ ]
 for OOo0oO00ooO00 in oOoO0 :
  for OOOO in range ( 0 , 4 ) :
   iI1111iiii . append ( '%s/random%sx%s.jpg' %
 ( os . path . dirname ( OOoooO00o0oo0 [ 'url' ] ) , OOo0oO00ooO00 , OOo0oO00ooO00 ) )
   if 77 - 77: iIii1I11I1II1 . o00 % o00 + i11iIiiIii
 OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
 OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
 OoO0O00O0oo0O [ 2 ] = 'Testing download speed...'
 I1i1i1 . update ( 50 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 if not simple :
  Ii11iI1i ( 'Testing download speed' , end = '' )
 Oo00o0OO0O00o = i1iI11i1ii11 ( iI1111iiii , simple )
 if not simple :
  Ii11iI1i ( )
 OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
 OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
 OoO0O00O0oo0O [ 2 ] = 'Download: %0.2f M%s/s' % ( ( Oo00o0OO0O00o / 1000 / 1000 ) * units [ 1 ] , units [ 0 ] )
 I1i1i1 . update ( 70 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 Ii11iI1i ( 'Download: %0.2f M%s/s' %
 ( ( Oo00o0OO0O00o / 1000 / 1000 ) * units [ 1 ] , units [ 0 ] ) )
 if 82 - 82: I1i1iI1i + OoooooooOO - i1IIi . i1IIi
 iIi1i = [ int ( .25 * 1000 * 1000 ) , int ( .5 * 1000 * 1000 ) ]
 oOoO0 = [ ]
 for OOo0oO00ooO00 in iIi1i :
  for OOOO in range ( 0 , 25 ) :
   oOoO0 . append ( OOo0oO00ooO00 )
   if 27 - 27: Oo0ooO0oo0oO * O0OOo . ooO00oOoo % Oo0oO0ooo * Oo0oO0ooo . i1IIi
 OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
 OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
 OoO0O00O0oo0O [ 2 ] = 'Testing upload speed...'
 I1i1i1 . update ( 80 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 if not simple :
  Ii11iI1i ( 'Testing upload speed' , end = '' )
 O0OOoOOO0oO = oO0OOOO0 ( OOoooO00o0oo0 [ 'url' ] , oOoO0 , simple )
 if not simple :
  Ii11iI1i ( )
 OoO0O00O0oo0O [ 0 ] = OoO0O00O0oo0O [ 1 ]
 OoO0O00O0oo0O [ 1 ] = OoO0O00O0oo0O [ 2 ]
 OoO0O00O0oo0O [ 2 ] = 'Upload: %0.2f M%s/s' % ( ( O0OOoOOO0oO / 1000 / 1000 ) * units [ 1 ] , units [ 0 ] )
 I1i1i1 . update ( 99 , OoO0O00O0oo0O [ 0 ] , OoO0O00O0oo0O [ 1 ] , OoO0O00O0oo0O [ 2 ] )
 Ii11iI1i ( 'Upload: %0.2f M%s/s' %
 ( ( O0OOoOOO0oO / 1000 / 1000 ) * units [ 1 ] , units [ 0 ] ) )
 if 28 - 28: O0OOo + i11iIiiIii / I1i1iI1i % OoOoOO00 % Oo0Ooo - O0
 if share and mini :
  Ii11iI1i ( 'Cannot generate a speedtest.net share results image while '
 'testing against a Speedtest Mini server' )
 elif share :
  ooo0OOO = int ( round ( ( Oo00o0OO0O00o / 1000 ) * 8 , 0 ) )
  iii1Ii1Ii1 = int ( round ( OOoooO00o0oo0 [ 'latency' ] , 0 ) )
  IIi = int ( round ( ( O0OOoOOO0oO / 1000 ) * 8 , 0 ) )
  if 94 - 94: II111iiii - Oo0Ooo
  if 91 - 91: Oo0Ooo
  if 31 - 31: Oo0ooO0oo0oO / i11iIiiIii % iIii1I11I1II1 + Oo0ooO0oo0oO / i11iIiiIii
  if 70 - 70: OoO0O00 * O0 . I1i1iI1i + I1IiiI . Oo0oO0ooo
  Ii1iIiII1Ii = [
 'download=%s' % ooo0OOO ,
 'ping=%s' % iii1Ii1Ii1 ,
 'upload=%s' % IIi ,
 'promo=' ,
 'startmode=%s' % 'pingselect' ,
 'recommendedserverid=%s' % OOoooO00o0oo0 [ 'id' ] ,
 'accuracy=%s' % 1 ,
 'serverid=%s' % OOoooO00o0oo0 [ 'id' ] ,
 'hash=%s' % md5 ( ( '%s-%s-%s-%s' %
 ( iii1Ii1Ii1 , IIi , ooo0OOO , '297aae72' ) )
 . encode ( ) ) . hexdigest ( ) ]
  if 42 - 42: O0 * o00ooo0 . Oo0Ooo - I1IiiI * iIii1I11I1II1
  i1II1 = { 'Referer' : 'https://c.speedtest.net/flash/speedtest.swf' }
  iIIiIi1iIII1 = O0oOO0 ( 'https://www.speedtest.net/api/api.php' ,
 data = '&' . join ( Ii1iIiII1Ii ) . encode ( ) ,
 headers = i1II1 )
  OooOOOOo = Ii1i ( iIIiIi1iIII1 )
  if OooOOOOo is False :
   Ii11iI1i ( 'Could not submit results to speedtest.net' )
   sys . exit ( 1 )
  iII111Ii = OooOOOOo . read ( )
  Ooo00OoOOO = OooOOOOo . code
  OooOOOOo . close ( )
  if 98 - 98: iIii1I11I1II1 * I1ii11iIi11i * Oo0ooO0oo0oO + O0OOo % i11iIiiIii % O0
  if int ( Ooo00OoOOO ) != 200 :
   Ii11iI1i ( 'Could not submit results to speedtest.net' )
   sys . exit ( 1 )
   if 27 - 27: O0
  OOO0oOOoo = parse_qs ( iII111Ii . decode ( ) )
  oOOO00o000o = OOO0oOOoo . get ( 'resultid' )
  if not oOOO00o000o or len ( oOOO00o000o ) != 1 :
   Ii11iI1i ( 'Could not submit results to speedtest.net' )
   sys . exit ( 1 )
   if 9 - 9: o0OO0 + I1i1iI1i / I1i1iI1i
  Ii11iI1i ( 'Share results: https://www.speedtest.net/result/%s.png' %
 oOOO00o000o [ 0 ] )
  global oo00o0Oo0oo
  oo00o0Oo0oo = oOOO00o000o [ 0 ]
  import time
  time . sleep ( 2 )
  I1i1i1 . close ( )
  Ii1I11ii1i = O0iIiIIIIIii ( )
  Ii1I11ii1i . doModal ( )
  del Ii1I11ii1i
  if 58 - 58: o0oOOo0O0Ooo / Oo0oO0ooo . OoOoOO00 / OoooooooOO + ooO00oOoo
  if 86 - 86: I1i1iI1i * I1IiiI + I1i1iI1i + II111iiii
  if 8 - 8: ooO00oOoo - o00 / O0OOo
class O0iIiIIIIIii ( xbmcgui . WindowDialog ) :
 def __init__ ( self ) :
  self . imgControl = xbmcgui . ControlImage ( 340 , 210 , 600 , 270 , 'https://www.speedtest.net/result/%s.png' % oo00o0Oo0oo )
  self . addControl ( self . imgControl )
  self . button0 = xbmcgui . ControlButton ( int ( 340 + 505 ) , int ( 210 + 206 ) , 80 , 50 , "[B]Close[/B]" )
  self . addControl ( self . button0 )
  self . setFocus ( self . button0 )
  if 96 - 96: OoOoOO00
 def onAction ( self , action ) :
  if action == II1Iiii1111i or action == i1IIi11111i :
   self . saveClose ( )
   if 29 - 29: I1ii11iIi11i / i1IIi . I1IiiI - OoOoOO00 - OoOoOO00 - o00ooo0
 def onControl ( self , control ) :
  if control == self . button0 :
   self . saveClose ( )
   if 20 - 20: i1IIi % OoO0O00 . I1IiiI / Oo0oO0ooo * i11iIiiIii * Oo0ooO0oo0oO
 def saveClose ( self ) :
  OOo = xbmcgui . Dialog ( )
  OOo . ok ( "[COLOR ghostwhite][B] Speed Test Powered By Ookla[/COLOR][/B]" ,"[COLOR red]2 Mbps + For SD Content [/COLOR]", "[COLOR orange]7 Mbps + For HD Content [/COLOR]","[COLOR green]15 Mbps + For 1080P Content[/COLOR]" )
  self . close ( )
  if 74 - 74: O0 / i1IIi
  if 78 - 78: OoooooooOO . OoO0O00 + O0OOo - i1IIi
class ii1O0 ( xbmcgui . WindowDialog ) :
 def __init__ ( self ) :
  self . imgControl = xbmcgui . ControlImage ( 340 , 210 , 600 , 270 , 'https://www.speedtest.net/result/4670696458.png' )
  self . addControl ( self . imgControl )
  self . button0 = xbmcgui . ControlButton ( int ( 340 + 505 ) , int ( 210 + 206 ) , 80 , 50 , "[B]Close[/B]" )
  self . addControl ( self . button0 )
  self . setFocus ( self . button0 )
  if 33 - 33: i1IIi
 def onAction ( self , action ) :
  if action == II1Iiii1111i or action == i1IIi11111i :
   self . saveClose ( )
   if 36 - 36: II111iiii % i11iIiiIii * OoOoOO00 + I1i1iI1i
 def onControl ( self , control ) :
  if control == self . button0 :
   self . saveClose ( )
   if 25 - 25: iIii1I11I1II1 % o00 . O0OOo
 def saveClose ( self ) :
  if 14 - 14: o0OO0 + I1ii11iIi11i - o00 / O0 . ooO00oOoo
  if 45 - 45: ooO00oOoo
  OOo = xbmcgui . Dialog ( )
  OOo . ok ( "[COLOR ghostwhite][B] Speed Test Powered By Ookla[/COLOR][/B]" ,"[COLOR red]2 Mbps + For SD Content [/COLOR]", "[COLOR orange]7 Mbps + For HD Content [/COLOR]","[COLOR green]15 Mbps + For 1080P Content[/COLOR]" )
  self . close ( )
  if 83 - 83: OoOoOO00 . OoooooooOO
  if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / Oo0oO0ooo / i11iIiiIii
if __name__ == '__main__' :
 i1Ii1i1I11Iii ( share = True , simple = True )
 if 62 - 62: OoO0O00 / I1ii11iIi11i
 if 7 - 7: OoooooooOO . Oo0oO0ooo
 if 53 - 53: o00ooo0 % o00ooo0 * o0oOOo0O0Ooo + OoOoOO00
 if 92 - 92: OoooooooOO + i1IIi / o00ooo0 * O0
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3